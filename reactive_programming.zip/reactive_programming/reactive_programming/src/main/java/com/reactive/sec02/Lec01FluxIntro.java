package com.reactive.sec02;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;

import java.util.List;

public class Lec01FluxIntro {
    public static void main(String[] args) {
        Flux<Integer> flux = Flux.just(1,2,3,4);

        flux.subscribe(Util.onNext(),
                Util.onError(),
                Util.onComplete());


        Flux<Object> fluxObj = Flux.just(1, 2, "Dharmesh", List.of("A", "B"));

        fluxObj.subscribe(Util.onNext(),
                Util.onError(),
                Util.onComplete());

        Flux<Object> fluxEmpty = Flux.empty();

        fluxEmpty.subscribe(Util.onNext(),
                Util.onError(),
                Util.onComplete());

        Flux.error(new RuntimeException("Testing exception")).subscribe(
                Util.onNext(),
                Util.onError(),
                Util.onComplete()
        );
    }
}
