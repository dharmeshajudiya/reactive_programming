package com.reactive.sec01;

import com.reactive.util.Util;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

public class Lec06SupplierRefactoring {
    public static void main(String[] args) {
        getName();
        getName()
                .subscribeOn(Schedulers.boundedElastic())
                .subscribe(Util.onNext());
        // block() is just for testing purpose doesn't use in real life
        String name = getName()
                .block();
        System.out.println(name);
        Util.sleepSecond(10);
    }

    public static Mono<String> getName() {
        System.out.println("Entered getName()");
        return Mono.fromSupplier(() -> {
            System.out.println("Generating name....");
            Util.sleepSecond(3);
            return Util.faker().name().fullName();
        }).map(String::toUpperCase);
    }
}
