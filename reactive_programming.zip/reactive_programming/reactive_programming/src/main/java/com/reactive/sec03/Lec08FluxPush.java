package com.reactive.sec03;

import com.reactive.sec03.helper.NameProducer;
import com.reactive.util.Util;
import reactor.core.publisher.Flux;

public class Lec08FluxPush {
    public static void main(String[] args) {
        // push() is not thread safe
        NameProducer nameProducer = new NameProducer();
        Flux.push(nameProducer)
                .subscribe(Util.subscriber("Name"));

        Runnable runnable = nameProducer::producer;

        for (int i = 0; i < 10; i++) {
            new Thread(runnable).start();
        }

        Util.sleepSecond(3);
    }
}
