package com.reactive.sec03;

import com.reactive.util.Util;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;

import java.util.Objects;

public class Lec01FluxCreate {
    public static void main(String[] args) {
        Flux.create(fluxSink -> {
            String country;
            do {
                country = Util.faker().country().name();
                fluxSink.next(country);
            } while (!StringUtils.equals(country.toLowerCase(), "india"));
            fluxSink.complete();
        }).subscribe(Util.subscriber("Country"));
    }
}
