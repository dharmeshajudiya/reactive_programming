package com.reactive.sec02;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;

import java.util.List;

public class Lec03FluxFromArrayOfList {
    public static void main(String[] args) {

        List<Integer> integerList = List.of(1, 2, 3, 4);
        Flux.fromIterable(integerList)
                .subscribe(Util.onNext());

        Integer[] integers = {5, 6, 7, 8};
        Flux.fromArray(integers)
                .subscribe(Util.onNext());
    }
}
