package com.reactive.sec02;

import com.reactive.sec02.helper.NameGenerator;
import com.reactive.util.Util;

import java.util.List;

public class Lec07FluxVsList {
    public static void main(String[] args) {
        List<String> name = NameGenerator.getNameList(5);
        System.out.println(name);

        NameGenerator.getNameFlux(5)
                .subscribe(Util.onNext());
    }
}
