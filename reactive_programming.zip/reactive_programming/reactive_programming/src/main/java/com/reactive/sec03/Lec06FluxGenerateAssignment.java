package com.reactive.sec03;

import com.reactive.util.Util;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;

public class Lec06FluxGenerateAssignment {
    public static void main(String[] args) {

        // country == india
        // max = 10
        // subscriber cancel exist
        Flux.generate(synchronousSink -> {
                    String countryName = Util.faker().country().name();
                    synchronousSink.next(countryName);

                    if(StringUtils.equals(countryName.toLowerCase(), "india"))
                        synchronousSink.complete();
                })
                .subscribe(Util.subscriber("Country2"));
    }
}
