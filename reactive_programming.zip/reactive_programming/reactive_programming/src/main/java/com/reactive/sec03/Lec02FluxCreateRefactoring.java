package com.reactive.sec03;

import com.reactive.sec03.helper.NameProducer;
import com.reactive.util.Util;
import reactor.core.publisher.Flux;

public class Lec02FluxCreateRefactoring {
    public static void main(String[] args) {
        NameProducer nameProducer = new NameProducer();
        Flux.create(nameProducer)
                .subscribe(Util.subscriber("Full Name"));

        Runnable runnable = nameProducer::producer;

        for (int i = 0; i < 10; i++) {
            new Thread(runnable).start();
        }

        Util.sleepSecond(2);
    }
}
