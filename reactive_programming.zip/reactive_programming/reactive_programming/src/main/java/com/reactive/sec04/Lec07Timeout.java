package com.reactive.sec04;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;

import java.time.Duration;

public class Lec07Timeout {
    public static void main(String[] args) {
        getOrderNumber()
                .timeout(Duration.ofSeconds(2), fallback())
                .subscribe(Util.subscriber("Timeout"));

        Util.sleepSecond(60);
    }

    private static Flux<Integer> getOrderNumber(){
        return Flux.range(1, 10)
                 .delayElements(Duration.ofSeconds(1));
                // .delayElements(Duration.ofSeconds(1));
                //.delayElements(Duration.ofSeconds(Util.faker().random().nextInt(1, 2)));
    }

    private static Flux<Integer> fallback() {
        return Flux.range(100, 10)
                .delayElements(Duration.ofSeconds(2));
    }
}
