package com.reactive.sec04;

import com.reactive.sec04.helper.OrderService;
import com.reactive.sec04.helper.User;
import com.reactive.sec04.helper.UserService;
import com.reactive.util.Util;

public class Lec12FlatMap {
    public static void main(String[] args) {
        UserService.getUser()
                .flatMap(user -> OrderService.getOrder(user.getUserId())) // mono / flux
                // .concatMap(user -> OrderService.getOrder(user.getUserId())) // mono / flux
                .subscribe(Util.subscriber("Order"));

        Util.sleepSecond(60);
    }
}
