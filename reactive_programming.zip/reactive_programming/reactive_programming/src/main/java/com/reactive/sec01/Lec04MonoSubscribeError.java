package com.reactive.sec01;

import com.reactive.util.Util;
import reactor.core.publisher.Mono;

public class Lec04MonoSubscribeError {
    public static void main(String[] args) {
        Mono<Integer> mono = Mono.just("ball")
                .map(String::length)
                .map(len -> len/0);

        // 1.
        // mono.subscribe();

        // 2.
        mono.subscribe(
                Util.onNext(),
                Util.onError(),
                Util.onComplete()
        );
    }
}
