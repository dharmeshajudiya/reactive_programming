package com.reactive.sec03;

import com.reactive.util.Util;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;

public class Lec05FluxGenerate {
    public static void main(String[] args) {
        // Allow to emmit only one item in SynchronousSink
        // SynchronousSink trigger emmit again and again

        Flux.generate(synchronousSink -> {
            synchronousSink.next(Util.faker().country().name());
        })
                .take(3)
                .subscribe(Util.subscriber("Country1"));
    }
}
