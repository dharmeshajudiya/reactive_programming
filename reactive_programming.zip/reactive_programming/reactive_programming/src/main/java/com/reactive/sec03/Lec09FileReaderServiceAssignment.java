package com.reactive.sec03;

import com.reactive.sec03.assignment.FileReaderService;
import com.reactive.util.Util;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Lec09FileReaderServiceAssignment {
    public static final Path PATH = Paths.get("src/main/resources/assignment/sec03");

    public static void main(String[] args) {
        FileReaderService fileReaderService = new FileReaderService();
        Path path = PATH.resolve("file01.txt");
        fileReaderService.read(path)
                /*.map(s -> {
                    Integer num = Util.faker().random().nextInt(1, 10);
                    if(num > 8)
                        throw new RuntimeException("Manual error.");
                    return s;
                })
                .take(20) */
                .subscribe(Util.subscriber("File"));
    }
}
