package com.reactive.sec04;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;

public class Lec08DefaultIfEmpty {
    public static void main(String[] args) {
        getOrderNumber()
                .filter(integer -> integer > 10)
                .defaultIfEmpty(-1)
                .subscribe(Util.subscriber("DefaultIfEmpty"));
    }

    private static Flux<Integer> getOrderNumber(){
        return Flux.range(1, 10);
    }
}
