package com.reactive.sec01;

import reactor.core.publisher.Mono;

public class Lec02MonoJust {
    public static void main(String[] args) {
        // Publisher
        Mono<Integer> justMono = Mono.just(1);
        System.out.println(justMono);

        // Never forget this rule: Nothing happen until you subscribe
        justMono.subscribe(integer -> System.out.println("Received : " + integer));
    }
}
