package com.reactive.sec02.helper;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.List;

public class NameGenerator {

    public static List<String> getNameList(int count) {
        List<String> names = new ArrayList<>();
        for(int index = 0; index < count; index++) {
            names.add(getName());
        }
        return names;
    }

    public static Flux<String> getNameFlux(int  count) {
        return Flux.range(0, count)
                .map(i -> getName());
    }

    private static String getName() {
        Util.sleepSecond(1);
        return Util.faker().name().fullName();
    }
}
