package com.reactive.sec04;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class Lec06OnErrorReturn {
    public static void main(String[] args) {
        Flux.range(1, 10)
                .log()
                .map(integer ->  10 / (5 - integer))
                // .onErrorReturn(-1)
                // .onErrorResume(throwable -> fallback())
                .onErrorContinue((throwable, obj) ->  {
                    System.out.println("Error cause by this Object " + obj);
                })
                .subscribe(Util.subscriber("OnError"));
         
    }

    private static Mono<Integer> fallback() {
        return Mono.fromSupplier(() -> Util.faker().random().nextInt(100, 200));
    }
}
