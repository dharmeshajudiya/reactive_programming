package com.reactive.sec01;

import java.util.stream.Stream;

public class Lec01Stream {
    public static void main(String[] args) {
        // Stream is Lazy so when any terminator is attached it execute code
         Stream<Integer> integerStream = Stream.of(1)
                 .map(integer -> {
                     try {
                         Thread.sleep(1000);
                     } catch (InterruptedException e) {
                         throw new RuntimeException(e);
                     }
                     return integer * 2;
                 });
         integerStream.forEach(System.out::println);
    }
}
