package com.reactive.sec01;

import com.reactive.util.Util;
import reactor.core.publisher.Mono;

import java.util.Objects;

public class Lec04MonoEmptyOrError {
    public static void main(String[] args) {
        System.out.println("Search for User Id : 1");
        userRepository(1)
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );

        System.out.println("Search for User Id : 2");
        userRepository(2)
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );

        System.out.println("Search for User Id : 3");
        userRepository(3)
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );
    }

    private static Mono<String> userRepository(int id) {
        if(Objects.equals(id, 1)) {
           return Mono.just(Util.faker().name().firstName());
        } else if(Objects.equals(id, 2)) {
            return Mono.empty();
        } else {
            return Mono.error(new RuntimeException("Given Id is not found in system. Please connect support team"));
        }
    }
}
