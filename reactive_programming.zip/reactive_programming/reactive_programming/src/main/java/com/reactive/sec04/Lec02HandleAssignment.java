package com.reactive.sec04;

import com.reactive.util.Util;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;

public class Lec02HandleAssignment {
    public static void main(String[] args) {
        // handle = filter + map
        Flux.generate(synchronousSink -> synchronousSink.next(Util.faker().country().name()))
                .map(Object::toString)
                .handle((countryName, synchronousSink) ->  {
                    synchronousSink.next(countryName); // map
                    if(StringUtils.equals(countryName.toLowerCase(), "india")) // filter
                        synchronousSink.complete();
                }).subscribe(Util.subscriber("Country"));
    }
}
