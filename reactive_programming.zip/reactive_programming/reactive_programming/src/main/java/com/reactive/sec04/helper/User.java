package com.reactive.sec04.helper;


import com.reactive.util.Util;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class User {
    private  int userId;
    private String name;

    public User(int userId) {
        this.userId = userId;
        this.name = Util.faker().name().fullName();
    }
}
