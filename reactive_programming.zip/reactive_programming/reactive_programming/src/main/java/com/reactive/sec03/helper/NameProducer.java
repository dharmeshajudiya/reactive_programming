package com.reactive.sec03.helper;

import com.reactive.util.Util;
import reactor.core.publisher.FluxSink;

import java.util.function.Consumer;

public class NameProducer implements Consumer<FluxSink<String>> {
    FluxSink<String> fluxSink;
    @Override
    public void accept(FluxSink<String> stringFluxSink) {
        this.fluxSink = stringFluxSink;
    }

    public void producer() {
        String fullName = Util.faker().name().fullName();
        String thread = Thread.currentThread().getName();
        fluxSink.next(thread + " : " +fullName);
    }
}
