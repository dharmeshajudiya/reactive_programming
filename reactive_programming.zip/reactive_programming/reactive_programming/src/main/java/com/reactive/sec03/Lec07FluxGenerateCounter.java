package com.reactive.sec03;

import com.reactive.util.Util;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Flux;

public class Lec07FluxGenerateCounter {
    public static void main(String[] args) {
        Flux.generate(
                () -> 1,
                (counter, sink) -> {
                    String countryName = Util.faker().country().name();
                    sink.next(countryName);
                    if(counter >= 10 || StringUtils.equals(countryName.toLowerCase(), "india"))
                        sink.complete();
                    return  ++counter;
                }
        )
                // .take(4)
                .subscribe(Util.subscriber("Country"));
    }
}
