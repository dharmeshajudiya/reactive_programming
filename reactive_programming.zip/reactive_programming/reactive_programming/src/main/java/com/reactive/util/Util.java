package com.reactive.util;

import com.github.javafaker.Faker;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Subscriber;

import java.util.Objects;
import java.util.function.Consumer;

public class Util {

    private static final Faker FAKER = Faker.instance();
    public static Consumer<Object> onNext() {
        return obj -> System.out.println("Received : " + obj);
    }

    public static Consumer<Throwable> onError() {
        return  throwable -> System.out.println(throwable.getMessage());
    }

    public static Runnable onComplete() {
        return () -> System.out.println("Completed.");
    }

    public static Faker faker() {
        return  FAKER;
    }

    public static void sleepSecond(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static Subscriber<Object> subscriber(String name){
        if(StringUtils.isEmpty(name))
            return new DefaultSubscriber();
        else
            return new DefaultSubscriber(name);

    }
}
