package com.reactive.sec01;

import com.reactive.util.Util;
import reactor.core.publisher.Mono;

import java.util.concurrent.Callable;
import java.util.function.Supplier;

public class Lec05MonoFromSupplier {
    public static void main(String[] args) {
        //  use just() only when you have data already
        // Mono<String> mono = Mono.just(getName());

        // fromSupplier() only invoked getName() if some one subscribe and call onNext()
        Supplier<String> supplier = () -> getName();
        Mono<String> mono = Mono.fromSupplier(supplier);
        mono.subscribe(
                Util.onNext()
        );

        Callable<String> callable = () -> getName();
        Mono.fromCallable(callable).subscribe(Util.onNext());
    }

    public static String getName() {
        System.out.println("Generating Name....");
        return Util.faker().name().fullName();
    }
}
