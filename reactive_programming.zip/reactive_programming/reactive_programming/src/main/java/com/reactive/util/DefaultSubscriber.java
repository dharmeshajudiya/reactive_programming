package com.reactive.util;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

public class DefaultSubscriber implements Subscriber<Object> {

    private String name = "";

    public DefaultSubscriber() { }
    public DefaultSubscriber(String name) {
        this.name = name;
    }

    @Override
    public void onSubscribe(Subscription subscription) {
        subscription.request(Integer.MAX_VALUE);
    }

    @Override
    public void onNext(Object o) {
        System.out.printf("%s - Received : %s.\n", name, o.toString());
    }

    @Override
    public void onError(Throwable throwable) {
        System.out.printf("%s - ERROR: %s.\n", name, throwable.getMessage());
    }

    @Override
    public void onComplete() {
        System.out.printf("%s - Completed.\n", name);
    }
}
