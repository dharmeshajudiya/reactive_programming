package com.reactive.sec01;

import com.reactive.sec01.assignment.FileService;
import com.reactive.util.Util;

public class Lec09AssignmentDemo {
    public static void main(String[] args) {
        FileService.read("file01.txt")
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );

        FileService.write("file03.txt", "This is file 3")
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );

        FileService.delete("file03.txt")
                .subscribe(
                        Util.onNext(),
                        Util.onError(),
                        Util.onComplete()
                );
    }
}
