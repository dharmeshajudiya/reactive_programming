package com.reactive.sec02;

import com.reactive.util.Util;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class Loc09FluxFromMono {
    public static void main(String[] args) {
         Mono<String> stringMono = Mono.just("Dharmesh");
         Flux<String> stringFlux = Flux.from(stringMono);
         doSomething(stringFlux);

         Flux.range(1, 10)
                 .filter(i -> i>3)
                 .next()
                 .subscribe(Util.onNext(), Util.onError(), Util.onComplete());
    }

    private static void doSomething(Flux<String> stringFlux) {
        stringFlux.subscribe(Util.onNext());
    }
}
